#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2020-04-12 00:10:04

#include "Arduino.h"
#include "Arduino.h"
#include <SdFat.h>
#include <LiquidCrystal.h>
#include <JC_Button.h>
#include "ESP8266.h"
#include <PWM.h>
#include <util/atomic.h>

unsigned int hex_a_decimal(String hexString) ;
byte hexDiseqcSwitch2ToInt(String command) ;
byte diseqcHexCantPulsos(String command) ;
byte obtenerCantidadPulsosMover(String command) ;
byte hexDiseqcSwitch1ToInt(String command) ;
void leerComandosDISEQC() ;
void procesarDISEQC(String data) ;
void diseqcMotor(String comando, String valor) ;
void diseqcSwitch(String tipoSwitch, String puerto) ;
void iniciarLCD() ;
void escribirLCD(String txt) ;
void refrescarLCD() ;
void dibujarLCD() ;
void dibujarMonitorDiseqc() ;
void dibujarLcdCompleta() ;
void dibujarLcdMotorMovimiento() ;
void borrarFilaLCD(byte fila);
void dibujarMenu(byte inicio, byte fin) ;
void mostrarMenu() ;
void mostrarSubMenu(int op) ;
void dibujarSubMenu(byte inicio, byte fin) ;
void subMenuFunciones() ;
void mostrarOpcion(int op) ;
void subMenuConfiguracionDiseqc() ;
void crearPatronBloqueo() ;
boolean desbloquearPosicionador() ;
void subMenuLimitesMotor() ;
void subMenuMotor1() ;
void subMenuMotor2() ;
void subMenuRecalcularPosiciones() ;
void seleccionarPosicion() ;
void subMenuSistema() ;
void sumarPulsosM1() ;
void restarPulsosM1() ;
void contarPulsosErroneosM1() ;
void sumarPulsosM2() ;
void restarPulsosM2() ;
void contarPulsosErroneosM2() ;
void moverMotor1Este(byte velocidad) ;
void moverMotor1Oeste(byte velocidad) ;
void moverMotor1EstePulso(int pulsos) ;
void moverMotor1OestePulso(int pulsos) ;
void pararMotor1() ;
void accionarMotor1() ;
void moverMotor2Este(byte velocidad) ;
void moverMotor2Oeste(byte velocidad) ;
void moverMotor2EstePulso(int pulsos) ;
void moverMotor2OestePulso(int pulsos) ;
void pararMotor2() ;
void accionarMotor2() ;
void controlProporcionalMotor1() ;
void controlProporcionalMotor2() ;
void dibujarDebugMotor(int sensor) ;
void loopMotoresParados() ;
void motor1aReferencia() ;
void motor2aReferencia() ;
void verificarConteoPulsos() ;
void moverMotorSeleccionadoEsteRapido() ;
void moverMotorSeleccionadoOesteRapido() ;
void moverMotorSeleccionadoEsteLento() ;
void moverMotorSeleccionadoOesteLento() ;
void moverMotorSeleccionadoEstePulso() ;
void moverMotorSeleccionadoOestePulso() ;
void pararMotorMovimiento() ;
void pararMotorMovimientoEsperar() ;
void noContarPulsos() ;
void desactivarLimitesMotor() ;
void setearLimiteEsteMotor() ;
void setearLimiteOesteMotor() ;
void gotoX(byte posDestino) ;
void gotoXmotor1(int pulsos) ;
void gotoXmotor2(int pulsos) ;
void bloquearPosicionador() ;
void tonoOk() ;
void tonoLimites() ;
void tonoNoPulseCount() ;
void tonoBloqueo() ;
void procesarComandosWifi(String comando, String datos) ;
void iniciarWifi() ;
void procesarWifi() ;
void leerBotones() ;
void guardarConfig() ;
void cargarConfig() ;
void guardarEstado() ;
void cargarEstado() ;
void borrarConfig() ;
String split(String data, char separator, int index) ;
int freeRam() ;
void borrarTodasPosicionesMemoria() ;
void editarPosicion(byte pos, String nombre, byte motor) ;
void guardarPosicion(byte pos) ;
void guardarNuevaPosicion(byte pos, String nombre, byte motor) ;
void cargarCrearPosicion(byte pos) ;
String obtenerPosicionesMemoria() ;
String obtenerNombreSat(byte pos) ;
void recalcularPosiciones() ;
void setup() ;
void loop() ;

#include "sdpArduino.ino"

#include "DISEQC_commandParser.ino"
#include "DISEQC_recibirComandos.ino"
#include "LCD.ino"
#include "LCD_menuConfiguracion.ino"
#include "LCD_menuFunciones.ino"
#include "LCD_subMenuConfiguracionDiseqc.ino"
#include "LCD_subMenuCrearPatronBloqueo.ino"
#include "LCD_subMenuDesbloquearPosicionador.ino"
#include "LCD_subMenuLimitesMotor.ino"
#include "LCD_subMenuMotor1.ino"
#include "LCD_subMenuMotor2.ino"
#include "LCD_subMenuRecalcularPosiciones.ino"
#include "LCD_subMenuSeleccionarPosicion.ino"
#include "LCD_subMenuSistema.ino"
#include "Motor_contarPulsosMotor1.ino"
#include "Motor_contarPulsosMotor2.ino"
#include "Motor_controlMotor1.ino"
#include "Motor_controlMotor2.ino"
#include "Motor_controlProporcionalMotor1.ino"
#include "Motor_controlProporcionalMotor2.ino"
#include "Motor_debugMotor.ino"
#include "Motor_loopMotoresParados.ino"
#include "Motor_motor1EnviarReferencia.ino"
#include "Motor_motor2EnviarReferencia.ino"
#include "Motor_verificarConteoPulsos.ino"
#include "Posicionador_funcionesControl.ino"
#include "Speaker_tonos.ino"
#include "WIFI_procesarComandos.ino"
#include "WIFI_recibirComandos.ino"
#include "botonera.ino"
#include "configuraciones.ino"
#include "funcionesVarias.ino"
#include "posiciones.ino"

#endif
