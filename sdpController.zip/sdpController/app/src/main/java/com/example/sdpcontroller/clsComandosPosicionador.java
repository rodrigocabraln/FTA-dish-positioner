package com.example.sdpcontroller;
import android.os.AsyncTask;
import android.util.Log;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class clsComandosPosicionador{
    //Ip del posicionador
    private String ipPosicionador;

    public void setIpPosicionador(String ipPosicionador) {
        this.ipPosicionador = ipPosicionador;
    }

    public String getIpPosicionador() {
        return  this.ipPosicionador;
    }

    //Envio de comando
    private void enviarComando(final String comando) {
        Log.d("Comando",comando);
        class enviarComando extends AsyncTask<Void, Void, Void> {
            @Override
            protected Void doInBackground(Void... params) {
                try {
                    String mensaje = comando;
                    byte[] mensajeBytes = mensaje.getBytes();
                    InetAddress ipDestino = InetAddress.getByName(ipPosicionador);
                    DatagramSocket socket = new DatagramSocket();
                    DatagramPacket paquete = new DatagramPacket(mensajeBytes, mensajeBytes.length, ipDestino, 4567);
                    socket.send(paquete);
                }catch (Exception e){
                    e.printStackTrace();
                }
                return null;
            }
        }

        new enviarComando().execute();
    }

    //Parar motor
    public void pararMotores(){
        Log.d("log","parar motores");
        enviarComando("sm");
    }

    //editar posicion
    public void editarPosicion(String nombre,int posicion,int motor){
        Log.d("log","editar posicion " + posicion);
        enviarComando("ep," + posicion + "," + nombre + "," + motor);
    }

    //Goto X
    public void  gotoXPosition (String posicion){
        Log.d("log","ir a posicion " + posicion);
        enviarComando("gx," + posicion);
    }

    //Goto ultima posicion
    public void  gotoUltimaPosicion (int motor){
        Log.d("log","ir a ultima posicion");
        enviarComando("gl," + motor);
    }

    //Goto X orbital
    public void  gotoXorbital (String posOrbital){
        Log.d("log","ir a " + posOrbital + "w");
        enviarComando("go," + posOrbital);
    }

    //Mover motor oeste
    public void moverMotorOeste(int pulsos,int motor){
        Log.d("log","Mover motor" + String.valueOf(motor) + " oeste " + String.valueOf(pulsos) + " pulsos");
        enviarComando("mw," + String.valueOf(pulsos) + "," + String.valueOf(motor));
    }

    //Mover motor oeste lento
    public void moverMotorOesteLentoContinuo(int motor){
        Log.d("log","Mover motor continuo" + String.valueOf(motor) + " oeste lento ");
        enviarComando("wl,0,"+ String.valueOf(motor));
    }

    //Mover motor oeste rapido
    public void moverMotorOesteRapidoContinuo(int motor){
        Log.d("log","Mover motor continuo" + String.valueOf(motor) + " oeste rapido ");
        enviarComando("mw,0,"+ String.valueOf(motor));
    }

    //Mover motor este
    public void moverMotorEste(int pulsos,int motor){
        Log.d("log","Mover motor" + String.valueOf(motor) + " este " + String.valueOf(pulsos) + " pulsos");
        enviarComando("me," + String.valueOf(pulsos) + "," + String.valueOf(motor));
    }

    //Mover motor este lento
    public void moverMotorEsteLentoContinuo(int motor){
        Log.d("log","Mover motor continuo" + String.valueOf(motor) + " este lento ");
        enviarComando("el,0," + String.valueOf(motor));
    }

    //Mover motor este rapido
    public void moverMotorEsteRapidoContinuo(int motor){
        Log.d("log","Mover motor continuo" + String.valueOf(motor) + " este rapido ");
        enviarComando("me,0," + String.valueOf(motor));
    }

    //Enviar motor a referencia
    public void enviarMotorReferencia(int motor){
        Log.d("log","Motor " +String.valueOf(motor) + " a referencia");
        enviarComando("gx,0");
    }

    //Cambiar motor seleccionado
    public void cambiarMotor(int motor){
        Log.d("log","Motor seleccionado " +String.valueOf(motor));
        enviarComando("ms," + String.valueOf(motor));
    }

    //Guardar posicion
    public void guardarPosicionActual(){
        Log.d("log","Guardar posicion actual");
        enviarComando("sp");
    }

    //Configura red wifi
    public void setarRedWifi(String ssid,String clave){
        Log.d("log","Configura Wifi");
        enviarComando("wf," + ssid + "," + clave);
    }

    //Llevar a x cantidad de pulsos
    public void gotoXpulsos(int pulsos,int motorSeleccionado){
        Log.d("log","Motor " +String.valueOf(motorSeleccionado) + " a " + String.valueOf(pulsos) + " pulsos");
        enviarComando("mp," + String.valueOf(motorSeleccionado) + "," + String.valueOf(pulsos));
    }

    //Obtener lista de posiciones almacenadas
    public String obtenerListaPosiciones(){
        String resultado = "nada";

        return resultado;
    }

    //Guardar una nueva posicion
    public void nuevaPosicion(int posicion,String nombre,int motor){
        Log.d("log","Crear posicion" + String.valueOf(posicion) + "," + nombre + "," + String.valueOf(motor));
        enviarComando("cp," + String.valueOf(posicion) + "," + nombre + "," + String.valueOf(motor));
    }

    //Cambiar nombre
    public void cambiarNombre(String nombre){
        Log.d("log","Cambiar nombre");
        enviarComando("np," + nombre);
    }





}
