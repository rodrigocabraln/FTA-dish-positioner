package com.example.sdpcontroller.ui.settings;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.sdpcontroller.MainActivity;
import com.example.sdpcontroller.R;
import com.example.sdpcontroller.clsComandosPosicionador;
import com.example.sdpcontroller.clsVariablesGlobales;
import com.example.sdpcontroller.frmControlPosicionador;
import com.example.sdpcontroller.frmSeleccionarRedWifi;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class settingsFragment extends Fragment {
    clsComandosPosicionador comandos;
    String ipPosicionador;
    //Utilizado para escanear redes wifi
    private WifiManager wifi;
    private List<ScanResult> resultadoEscaneoWifi;
    private ArrayList<String> arrayListaWifis = new ArrayList<>();
    private ArrayAdapter adapterWifi;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_settings, container, false);
        //Instanciamos la clase para enviar los comandos
        comandos= new clsComandosPosicionador();
        final clsVariablesGlobales variablesGlobales = (clsVariablesGlobales) getActivity().getApplicationContext();
        comandos.setIpPosicionador(variablesGlobales.getIpPosicionador());
        ipPosicionador = variablesGlobales.getIpPosicionador();

        //Cambiar nombre posicionador
        final EditText txtNombrePosicionador = root.findViewById(R.id.txtNombrePosicionador);
        Button btnGuardarNombrePosicionador = root.findViewById(R.id.btnGuardarNombre);
        btnGuardarNombrePosicionador.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nombre = txtNombrePosicionador.getText().toString();
                //No se acepta el caracter | porque es el separador de la cadena
                nombre = nombre.replace("|",".");
                comandos.cambiarNombre(nombre);
                mensaje("Command sent successfully");
            }
        });

        //Conectar a una red WIFI
        Button btnWifi = root.findViewById(R.id.btnCambiarWifi);
        btnWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Abrimos la activity
                Intent intent = new Intent(view.getContext(), frmSeleccionarRedWifi.class);
                startActivity(intent);
            }
        });


        return root;
    }

    //Mensaje
    private void mensaje(String msg){
        Snackbar snackBar = Snackbar.make(getActivity().findViewById(android.R.id.content),
                msg, Snackbar.LENGTH_LONG);
        snackBar.show();
    }
}
