package com.example.sdpcontroller;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;


import java.util.List;

public class arrayAdapterPosicionadores extends ArrayAdapter<clsPosicionadores> {
    private LayoutInflater layoutInflater;
    Context mContext;

    public arrayAdapterPosicionadores(Context context, List<clsPosicionadores> objects) {
        super(context, 0, objects);
        layoutInflater = LayoutInflater.from(context);
        mContext = context;
    }

    @Override
    public View getView(int position, View convertView, final ViewGroup parent) {
        // holder pattern
        arrayAdapterPosicionadores.Holder holder = null;
        if (convertView == null) {
            holder = new arrayAdapterPosicionadores.Holder();

            convertView = layoutInflater.inflate(R.layout.item_lista_posicionadores, null);
            holder.setTextViewNombre((TextView) convertView.findViewById(R.id.lblNombrePosicionador));
            holder.setTextViewIp((TextView) convertView.findViewById(R.id.lblIPposicionador));
            convertView.setTag(holder);
        } else {
            holder = (arrayAdapterPosicionadores.Holder) convertView.getTag();
        }

        final clsPosicionadores row = getItem(position);
        holder.getTextViewNombre().setText(row.getNombre());
        holder.getTextViewIp().setText(row.getIp());

        return convertView;
    }

    static class Holder {
        TextView textViewNombre;
        TextView textViewIp;

        public TextView getTextViewIp() {
            return textViewIp;
        }

        public void setTextViewIp(TextView textViewIp) {
            this.textViewIp = textViewIp;
        }

        public TextView getTextViewNombre() {
            return textViewNombre;
        }

        public void setTextViewNombre(TextView textViewNombre) {
            this.textViewNombre = textViewNombre;
        }
    }
}