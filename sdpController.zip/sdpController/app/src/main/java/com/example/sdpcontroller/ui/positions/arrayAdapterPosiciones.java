package com.example.sdpcontroller.ui.positions;

import android.content.Context;
import android.media.Image;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import com.example.sdpcontroller.R;
import java.util.List;

public class arrayAdapterPosiciones extends ArrayAdapter<clsPosiciones> {
    private LayoutInflater layoutInflater;
    Context mContext;

    public arrayAdapterPosiciones(Context context, List<clsPosiciones> objects) {
        super(context, 0, objects);
        layoutInflater = LayoutInflater.from(context);
        mContext = context;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        // holder pattern
        arrayAdapterPosiciones.Holder holder = null;
        if (convertView == null) {
            holder = new arrayAdapterPosiciones.Holder();

            convertView = layoutInflater.inflate(R.layout.item_lista_posiciones, null);
            holder.setTextViewNombre((TextView) convertView.findViewById(R.id.lblNombrePosicion));
            holder.setTextViewPosicion((TextView) convertView.findViewById(R.id.lbl_numero_posicion));
            holder.setTextViewMotor((TextView) convertView.findViewById(R.id.lblMotorPosicion));
            holder.setBtnEditarPosicion((ImageButton) convertView.findViewById(R.id.btnEditarPosicion));
            holder.setBtnGotoPosicion((ImageButton) convertView.findViewById(R.id.btnGotoPosicion));

            convertView.setTag(holder);
        } else {
            holder = (arrayAdapterPosiciones.Holder) convertView.getTag();
        }

        //boton de editar
        ImageButton btnEditar = convertView.findViewById(R.id.btnEditarPosicion);
        btnEditar.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             ((ListView)parent).performItemClick(v,position,0);
                                         }
                                     }
        );

        //boton goto posicion
        ImageButton btnGotoPos = convertView.findViewById(R.id.btnGotoPosicion);
        btnGotoPos.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {
                                              ((ListView)parent).performItemClick(v,position,0);
                                          }
                                      }
        );

        final clsPosiciones row = getItem(position);
        holder.getTextViewNombre().setText(row.getNombre());
        holder.getTextViewPosicion().setText(String.valueOf(row.getPosicion()));
        holder.getTextViewMotor().setText(String.valueOf(row.getMotor()));
        holder.getBtnEditarPosicion().setImageResource(R.drawable.ic_edit_regular);
        holder.getBtnGotoPosicion().setImageResource(R.drawable.ic_subdirectory_arrow_right_black_24dp);
        return convertView;
    }

    static class Holder {
        TextView textViewNombre;
        TextView textViewPosicion;
        TextView textViewMotor;
        ImageButton btnEditarPosicion;
        ImageButton btnGotoPosicion;

        public TextView getTextViewPosicion() {
            return textViewPosicion;
        }

        public void setTextViewPosicion(TextView textViewPosicion) {
            this.textViewPosicion = textViewPosicion;
        }

        public TextView getTextViewMotor() {
            return textViewMotor;
        }

        public void setTextViewMotor(TextView textViewMotor) {
            this.textViewMotor = textViewMotor;
        }

        public TextView getTextViewNombre() {
            return textViewNombre;
        }

        public void setTextViewNombre(TextView textViewNombre) {
            this.textViewNombre = textViewNombre;
        }

        public ImageButton getBtnEditarPosicion() {
            return btnEditarPosicion;
        }

        public void setBtnEditarPosicion(ImageButton btnEditarPosicion) {
            this.btnEditarPosicion = btnEditarPosicion;
        }

        public ImageButton getBtnGotoPosicion() {
            return btnGotoPosicion;
        }

        public void setBtnGotoPosicion(ImageButton btnGotoPosicion) {
            this.btnGotoPosicion = btnGotoPosicion;
        }
    }
}