package com.example.sdpcontroller;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import java.util.List;

public class arrayAdapterRedesWifi extends ArrayAdapter<String> {
    private LayoutInflater layoutInflater;
    Context mContext;

    public arrayAdapterRedesWifi(Context context, List<String> objects) {
        super(context, 0, objects);
        layoutInflater = LayoutInflater.from(context);
        mContext = context;
    }

    @Override
    public View getView(final int position, View convertView, final ViewGroup parent) {
        // holder pattern
        arrayAdapterRedesWifi.Holder holder = null;
        if (convertView == null) {
            holder = new arrayAdapterRedesWifi.Holder();

            convertView = layoutInflater.inflate(R.layout.item_lista_wifi, null);
            holder.setTextViewNombre((TextView) convertView.findViewById(R.id.lblNombreWifi));

            convertView.setTag(holder);
        } else {
            holder = (arrayAdapterRedesWifi.Holder) convertView.getTag();
        }

        //boton conectar
        ImageButton btnConectar = convertView.findViewById(R.id.btnConectarWifi);
        btnConectar.setOnClickListener(new View.OnClickListener() {
                                         @Override
                                         public void onClick(View v) {
                                             ((ListView)parent).performItemClick(v,position,0);
                                         }
                                     }
        );

        final String row = getItem(position);
        holder.getTextViewNombre().setText(row);
        return convertView;
    }

    static class Holder {
        TextView textViewNombre;

        public TextView getTextViewNombre() {
            return textViewNombre;
        }

        public void setTextViewNombre(TextView textViewNombre) {
            this.textViewNombre = textViewNombre;
        }
    }
}