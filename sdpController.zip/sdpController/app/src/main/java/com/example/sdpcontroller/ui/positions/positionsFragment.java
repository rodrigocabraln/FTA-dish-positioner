package com.example.sdpcontroller.ui.positions;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.InputFilter;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.example.sdpcontroller.MainActivity;
import com.example.sdpcontroller.R;
import com.example.sdpcontroller.clsComandosPosicionador;
import com.example.sdpcontroller.clsPosicionadores;
import com.example.sdpcontroller.clsVariablesGlobales;
import com.example.sdpcontroller.frmControlPosicionador;
import com.example.sdpcontroller.ui.control.ControlFragment;
import com.google.android.material.snackbar.Snackbar;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class positionsFragment extends Fragment {
    List<clsPosiciones> arrayPosiciones;
    clsComandosPosicionador comandos;
    String ipPosicionador;
    ListView listaPosiciones = null;
    ConstraintLayout layoutCarga;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragment_positions, container, false);

        //Animacion de carga
        layoutCarga = root.findViewById(R.id.layoutCargandoPosiciones);
        layoutCarga.setVisibility(View.GONE);

        //Array que almacena los posicionadores encontrados en la red
        arrayPosiciones = new ArrayList<clsPosiciones>();

        //Instanciamos la clase para enviar los comandos
        comandos= new clsComandosPosicionador();
        final clsVariablesGlobales variablesGlobales = (clsVariablesGlobales) getActivity().getApplicationContext();
        comandos.setIpPosicionador(variablesGlobales.getIpPosicionador());
        ipPosicionador = variablesGlobales.getIpPosicionador();

        //Lista de posiciones
        listaPosiciones = root.findViewById(R.id.lstPosiciones);

        //Listeners para los clic en la lista
        listaPosiciones.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long id)
            {
                //toca editar posicion
                if(view.getId() == R.id.btnEditarPosicion) {
                    clsPosiciones laPosicion = arrayPosiciones.get(i);
                    editarPosicion(laPosicion);
                }

                //toca ir a posicion
                if(view.getId() == R.id.btnGotoPosicion) {
                    clsPosiciones laPosicion = arrayPosiciones.get(i);
                    comandos.gotoXPosition(String.valueOf(laPosicion.getPosicion()));
                }
            }
        });

        //Obtengo las posiciones satelitales almacenadas
        obtenerPosicionesSatelitales();

        return root;
    }

    //OBTENER EL LISTADO DE POSICIONES ALMACENADAS EN EL POSICIONADOR
    void obtenerPosicionesSatelitales() {
        class asyncObtenerPosiciones extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                String listaPosiciones = "";
                try {
                    String comando = "gp"; //comando para que nos devuelva la lista de posiciones
                    byte[] comandoBytes = comando.getBytes();
                    InetAddress ipBroadcast = InetAddress.getByName(ipPosicionador);
                    DatagramSocket socket = new DatagramSocket();
                    DatagramPacket paquete = new DatagramPacket(comandoBytes, comandoBytes.length, ipBroadcast, 4567);
                    socket.send(paquete);

                    //Esperar la respuesta
                    while (true) {
                        try {
                            byte[] respuesta = new byte[32000];
                            DatagramPacket paqueteRespuesta = new DatagramPacket(respuesta, respuesta.length);
                            socket.setSoTimeout(15000); //esperamos 15 segundos para obtener la posiciones
                            socket.receive(paqueteRespuesta);
                            listaPosiciones = new String(respuesta, 0, paqueteRespuesta.getLength());
                            //si hay datos salimos del bucle
                            if (listaPosiciones.length() > 0){
                                break;
                            }
                        } catch (Exception e) { //si se genera una excepcion rompo el bucle
                            //e.printStackTrace();
                            break;
                        }
                    }
                    socket.close(); //cierro la conexion
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return listaPosiciones;
            }

            @Override
            protected void onPostExecute(String result) {
                //Verifico si tenemos algo
                if (!result.equals("")) {
                   /* Las posiciones estan formadas de la sigueinte manera:
                    numeroPosicion!nombre ademas cada una esta separada por ,
                    */
                   //Separo las posiciones
                    String[] posiciones = result.split(",");

                    Log.d("log", "Posiciones encontradas:");
                    for(int i=0; i<posiciones.length; i++){
                        Log.d("posicion:",posiciones[i].toString());

                        //Para cada posicion creo un objeto del tipo clsPosicion y lo cargo al array
                        String[] unaPosicion = posiciones[i].split("!"); //separamos la posicion para obtener el nombre y el numero de posicion
                        clsPosiciones laPosicion = new clsPosiciones();
                        laPosicion.setPosicion(Integer.parseInt(unaPosicion[0]));
                        laPosicion.setNombre(unaPosicion[1]);
                        laPosicion.setMotor(Integer.parseInt(unaPosicion[2]));
                        //Lo cargo al array
                        arrayPosiciones.add(laPosicion);
                    }

                    //Cargamos la lista
                    listarPosiciones();
                } else {
                    Log.d("log", "No se encontraron posiciones");
                    mostrarMensaje("No positions stored");
                }

                //Termina la carga
                layoutCarga.setVisibility(View.GONE);
            }

            @Override
            protected void onPreExecute() {
                //Obteniendo posiciones
                Log.d("log","Obteniendo posiciones");
                layoutCarga.setVisibility(View.VISIBLE);
            }

            @Override
            protected void onProgressUpdate(Void... values) {
            }
        }
        new asyncObtenerPosiciones().execute();
    }

    //Listar posiciones
    private void listarPosiciones() {
        listaPosiciones.setAdapter(new arrayAdapterPosiciones(getActivity().getApplicationContext(), arrayPosiciones));
    }

    //Editar una posicion
    private void editarPosicion(final clsPosiciones laPosicion){
        //creo un alert dialog con un layout personalizado
        final View customLayout = getLayoutInflater().inflate(R.layout.layout_editar_posicion, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        //Titulo
        TextView titulo = new TextView(getActivity());
        titulo.setText("Edit position " + String.valueOf(laPosicion.getPosicion()));
        titulo.setPadding(32, 32, 32, 32);
        titulo.setTextSize(20F);
        titulo.setTextColor(Color.WHITE);

        builder.setCustomTitle(titulo);

        final EditText txtNombre = customLayout.findViewById(R.id.txtNombrePosicion);
        txtNombre.setText(laPosicion.getNombre());

        //Motor seleccionado
        final RadioButton radioMotor1 = customLayout.findViewById(R.id.radioMotor1);
        final RadioButton radioMotor2 = customLayout.findViewById(R.id.radioMotor2);

        if (laPosicion.getMotor() == 1){
            radioMotor1.setChecked(true);
        } else if(laPosicion.getMotor() == 2){
            radioMotor2.setChecked(true);
        }

        //seteo el customlayout
        builder.setView(customLayout);

        // botones
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Validar datos
                try {
                    if (radioMotor1.isChecked()){
                        laPosicion.setMotor(1);
                    } else if (radioMotor2.isChecked()){
                        laPosicion.setMotor(2);
                    }
                    comandos.editarPosicion(txtNombre.getText().toString(), laPosicion.getPosicion(),laPosicion.getMotor());
                }catch (Exception e){

                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //cancelar
            }
        });

        // muestro el dialogo
        AlertDialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#303030")));
        dialog.getWindow().setTitleColor(Color.parseColor("#FFFFFF"));

        dialog.show();
    }

    //Mostrar un mensaje
    private void mostrarMensaje(String msg){
        Snackbar snackBar = Snackbar.make(getActivity().findViewById(android.R.id.content),
                msg, Snackbar.LENGTH_LONG);
        snackBar.show();
    }
}
