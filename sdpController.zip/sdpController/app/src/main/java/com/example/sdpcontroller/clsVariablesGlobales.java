package com.example.sdpcontroller;

import android.app.Application;

public class clsVariablesGlobales extends Application {
    private String ipPosicionador;


    public String getIpPosicionador() {
        return ipPosicionador;
    }

    public void setIpPosicionador(String ipPosicionador) {
        this.ipPosicionador = ipPosicionador;
    }
}
