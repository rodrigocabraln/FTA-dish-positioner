package com.example.sdpcontroller;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.media.MediaDataSource;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sdpcontroller.ui.positions.clsPosiciones;

import java.util.ArrayList;
import java.util.List;

public class frmSeleccionarRedWifi extends AppCompatActivity {
    //Utilizado para escanear redes wifi
    private WifiManager wifi;
    private List<ScanResult> resultadoEscaneoWifi;
    private ArrayList<String> arrayListaWifis = new ArrayList<>();
    private ArrayAdapter adapterWifi;
    ListView listaWifi;
    String ssidSeleccionado = "";
    String claveWifi = "";
    List<clsPosiciones> arrayPosiciones;
    clsComandosPosicionador comandos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frm_seleccionar_red_wifi);
        setTitle("Select WIFI network");

        //Necesitamos ciertos permisos para escanear las redes wifi
        pedirPermisosUbicacion();

        //Instanciamos la clase para enviar los comandos
        comandos= new clsComandosPosicionador();
        final clsVariablesGlobales variablesGlobales = (clsVariablesGlobales) getApplicationContext();
        comandos.setIpPosicionador(variablesGlobales.getIpPosicionador());

        //Se oculta el layout de la clave
        final ConstraintLayout layoutClave = findViewById(R.id.layoutClaveWifi);
        layoutClave.setVisibility(View.GONE);

        //Listener al hacer clic en una red wifi
        listaWifi = findViewById(R.id.lstRedesWifi);
        listaWifi.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long id)
            {
                //al tocar conectarse a la red
                if(view.getId() == R.id.btnConectarWifi) {
                    //Ocultamos la lista
                    listaWifi.setVisibility(View.GONE);
                    //Mostramos para ingresar la clave
                    TextView lblWifiSeleccionada = findViewById(R.id.wifiSeleccionado);
                    ssidSeleccionado = arrayListaWifis.get(i);
                    lblWifiSeleccionada.setText(ssidSeleccionado);
                    layoutClave.setVisibility(View.VISIBLE);
                }
            }
        });

        //Boton escanear WIFI
        Button btnScanWifi = findViewById(R.id.btnScanWifi);
        btnScanWifi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Se resetea el form
                ssidSeleccionado ="";
                claveWifi="";
                layoutClave.setVisibility(View.GONE);
                listaWifi.setVisibility(View.VISIBLE);
                //Comenzar escaneo de redes
                escanearRedesWifi();
            }
        });

        //Boton conectar WIFI
        Button btnConectar = findViewById(R.id.btnConectarRedWifi);
        btnConectar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText txtPassWifi = findViewById(R.id.txtPassWordWifi);
                claveWifi = txtPassWifi.getText().toString();
                //Envio el comando
                comandos.setarRedWifi(ssidSeleccionado,claveWifi);
                finish(); //salimos
            }
        });
    }

    //es necesario tener permisos del GPS para escanear las redes WIFI
    //https://developer.android.com/reference/android/net/wifi/WifiManager
    private void pedirPermisosUbicacion() {
        try { //ubicacion
            if (ContextCompat.checkSelfPermission(frmSeleccionarRedWifi.this,
                    Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_DENIED) {
                ActivityCompat.requestPermissions(frmSeleccionarRedWifi.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        101);
            }

            if (ContextCompat.checkSelfPermission(frmSeleccionarRedWifi.this,
                    Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_DENIED) {
                ActivityCompat.requestPermissions(frmSeleccionarRedWifi.this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                        101);
            }

            //escanear redes wifi
            if (ContextCompat.checkSelfPermission(frmSeleccionarRedWifi.this,
                    Manifest.permission.CHANGE_WIFI_STATE) == PackageManager.PERMISSION_DENIED) {
                ActivityCompat.requestPermissions(frmSeleccionarRedWifi.this,
                        new String[]{Manifest.permission.CHANGE_WIFI_STATE},
                        101);
            }

            if (ContextCompat.checkSelfPermission(frmSeleccionarRedWifi.this,
                    Manifest.permission.CHANGE_NETWORK_STATE) == PackageManager.PERMISSION_DENIED) {
                ActivityCompat.requestPermissions(frmSeleccionarRedWifi.this,
                        new String[]{Manifest.permission.CHANGE_NETWORK_STATE},
                        101);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //ESCANEAR TODAS LAS REDES WIFI Y LISTARLAS
    BroadcastReceiver wifiReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            resultadoEscaneoWifi = wifi.getScanResults();
            unregisterReceiver(this);

            for (ScanResult scanResult : resultadoEscaneoWifi) {
                arrayListaWifis.add(scanResult.SSID);
                adapterWifi.notifyDataSetChanged();
            }
        }
    };

    private void escanearRedesWifi() {
        wifi = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        arrayListaWifis.clear(); //limpiar la lista
        adapterWifi = new arrayAdapterRedesWifi(this, arrayListaWifis);
        registerReceiver(wifiReceiver, new IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION));
        Toast.makeText(getApplicationContext(), "Scanning WiFi ...", Toast.LENGTH_LONG).show();
        wifi.startScan();

        //setear el arrayadapter a la lista
        listaWifi.setAdapter(adapterWifi);
    }
}
