package com.example.sdpcontroller.ui.control;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.example.sdpcontroller.R;
import com.example.sdpcontroller.clsComandosPosicionador;
import com.example.sdpcontroller.clsPosicionadores;
import com.example.sdpcontroller.clsVariablesGlobales;
import com.google.android.material.snackbar.Snackbar;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ControlFragment extends Fragment {
    //Variables de control
    int velocidadMovimiento = 1; // 1 maximo, 2 lento
    int motorSeleccionado = 1; // 1 o 2
    boolean moviendoMotorContinuo = false; //true cuando se empieza a mover con el movmiento continuo
    int pulsosMoverMotor = 1; //Contiene la cantidad de pasos a mover
    View view;

    clsComandosPosicionador comandos; //Clase para enviar los comandos

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        final View root = inflater.inflate(R.layout.fragment_control, container, false);

        //Instanciamos la clase para enviar los comandos
        comandos= new clsComandosPosicionador();
        final clsVariablesGlobales variablesGlobales = (clsVariablesGlobales) getActivity().getApplicationContext();
        comandos.setIpPosicionador(variablesGlobales.getIpPosicionador());

        //Al cambiar el texto de los pulsos a mover, lo seteamos en la variable
        final EditText txtPulsosMover = root.findViewById(R.id.txtCantPulsos);
        txtPulsosMover.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
            }

            @Override
            public void beforeTextChanged(CharSequence s, int start,int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start,int before, int count) {
                if (s.length() > 0){
                    pulsosMoverMotor = Integer.parseInt(txtPulsosMover.getText().toString());
                    Log.d("log","Pulsos mover " + pulsosMoverMotor);
                }
            }
        });

        //Botones de movimiento
        final ImageButton btnEste = root.findViewById(R.id.btnMoverDerecha);
        final ImageButton btnOeste = root.findViewById(R.id.btnMoverIzquierda);

        //MOVIMIENTO ESTE CONTINUO
        btnEste.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                moverMotorEsteContinuo();
                return true;
            }
        });

        //MOVIMIENTO ESTE X PULSOS
        btnEste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comandos.moverMotorEste(pulsosMoverMotor,motorSeleccionado);
                mostrarMensaje("Command sent");
            }
        });

        //MOVIMIENTO ESTE SUELTA BOTON
        btnEste.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        if(moviendoMotorContinuo == true){
                            pararMotor();
                            mostrarMensaje("Stop motor");
                        }
                        return false;
                }
                return false;
            }
        });

        //MOVIMIENTO OESTE CONTINUO
        btnOeste.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                moverMotorOesteContinuo();
                return true;
            }
        });

        //MOVIMIENTO OESTE X PULSOS
        btnOeste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comandos.moverMotorOeste(pulsosMoverMotor,motorSeleccionado);
                mostrarMensaje("Command sent");
            }
        });

        //MOVIMIENTO OESTE SUELTA BOTON
        btnOeste.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch(event.getAction()) {
                    case MotionEvent.ACTION_UP:
                        if(moviendoMotorContinuo == true){
                            pararMotor();
                            mostrarMensaje("Stop motor");
                        }
                        return false;
                }
                return false;
            }
        });

        //CAMBIO DE MOTOR SELECCIONADO
        final ImageButton btnMotor1 = root.findViewById(R.id.btnMotor1);
        final ImageButton btnMotor2 = root.findViewById(R.id.btnMotor2);

        btnMotor1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                motorSeleccionado = 1;
                btnMotor1.setColorFilter(Color.parseColor("#FF0266")); //color seleccionado
                btnMotor2.setColorFilter(Color.WHITE); //color original
                comandos.cambiarMotor(motorSeleccionado);
                mostrarMensaje("Command sent");
            }
        });

        btnMotor2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                motorSeleccionado = 2;
                btnMotor2.setColorFilter(Color.parseColor("#FF0266")); //color seleccionado
                btnMotor1.setColorFilter(Color.WHITE); //color original
                comandos.cambiarMotor(motorSeleccionado);
                mostrarMensaje("Command sent");
            }
        });

        //PARAR MOTORES
        Button btnStop = root.findViewById(R.id.btnPararMotor);
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                pararMotor();
                mostrarMensaje("Motor stop");
            }
        });


        //Seleccion de velocidad
        RadioButton radioVelocidadMaxima = root.findViewById(R.id.radioMaximaVelocidad);
        radioVelocidadMaxima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                velocidadMovimiento = 1;
                if (moviendoMotorContinuo == true){
                    pararMotor();
                }
            }
        });

        RadioButton radioVelocidadLenta = root.findViewById(R.id.radioMinimaVelocidad);
        radioVelocidadLenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                velocidadMovimiento = 2;
                if (moviendoMotorContinuo == true){
                    pararMotor();
                }
            }
        });



        //Guardar posicion
        Button btnGuardarPosicion = root.findViewById(R.id.btnGuardarPosicion);
        btnGuardarPosicion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comandos.guardarPosicionActual();
                mostrarMensaje("Command sent");
            }
        });

        //Ir a referencia
        Button btnReferencia = root.findViewById(R.id.btnGotoReference);
        btnReferencia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comandos.enviarMotorReferencia(motorSeleccionado);
                mostrarMensaje("Command sent");
            }
        });

        //Ir a x pulsos
        final EditText txtPulsosDestino = root.findViewById(R.id.txtPulsosDestino);
        Button btnIrPulsosDestino = root.findViewById(R.id.btnIrAXpulsos);
        btnIrPulsosDestino.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    comandos.gotoXpulsos(Integer.parseInt(txtPulsosDestino.getText().toString()),motorSeleccionado);
                    mostrarMensaje("Command sent");
                }catch (Exception e){
                    Log.d("log","error al parsear pulsos destino");
                }
            }
        });

        //Ir a la ultima posicion
        Button btnGotoUltimaPosicion = root.findViewById(R.id.btnGotoPosicionActual);
        btnGotoUltimaPosicion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                comandos.gotoUltimaPosicion(motorSeleccionado);
                mostrarMensaje("Command sent");
            }
        });

        //Nueva posicion
        Button btnNuevaPosicion = root.findViewById(R.id.btnNuevaPosicion);
        btnNuevaPosicion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                crearNuevaPosicion();
            }
        });

        //Iniciar
        obtenerStatusPosicionador(root);

        //Retorna la vista
        view = root;
        return root;
    }

    //MOVER EL MOTOR CONTINUAMENTE HASTA EL ESTE
    private void moverMotorEsteContinuo(){
        moviendoMotorContinuo = true;
        //Dependiendo de la velocidad, el comando a enviar
        if (velocidadMovimiento == 1){
            comandos.moverMotorEsteRapidoContinuo(motorSeleccionado);
        }else if(velocidadMovimiento == 2){
            comandos.moverMotorEsteLentoContinuo(motorSeleccionado);
        }
    }

    //MOVER EL MOTOR CONTINUAMENTE HASTA EL OESTE
    private void moverMotorOesteContinuo(){
        moviendoMotorContinuo = true;
        //Dependiendo de la velocidad, el comando a enviar
        if (velocidadMovimiento == 1){
            comandos.moverMotorOesteRapidoContinuo(motorSeleccionado);
        }else if(velocidadMovimiento == 2){
            comandos.moverMotorOesteLentoContinuo(motorSeleccionado);
        }
    }

    //PARAR MOTORES
    private void  pararMotor(){
        //Envio comando
        comandos.pararMotores();
        //Paro motor
        moviendoMotorContinuo = false;


        //Actualizo el estado
        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                obtenerStatusPosicionador(view);
            }
        }, 3000);
    }

    //CREAR UNA NUEVA POSICION
    private void crearNuevaPosicion(){
        //creo un alert dialog con un layout personalizado
        final View customLayout = getLayoutInflater().inflate(R.layout.layout_new_position, null);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());

        //Titulo
        TextView titulo = new TextView(getActivity());
        titulo.setText("New position");
        titulo.setPadding(32, 32, 32, 32);
        titulo.setTextSize(20F);
        titulo.setTextColor(Color.WHITE);

        builder.setCustomTitle(titulo);

        //seteo el customlayout
        builder.setView(customLayout);

        // botones
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Validar datos
                EditText txtNombre = customLayout.findViewById(R.id.txtNombrePosicion);
                EditText txtPos = customLayout.findViewById(R.id.txtPosicion);
                //si no esta vacio
                if ((txtNombre.getText().toString().length() > 0 ) && (txtPos.getText().toString().length() > 0 )){
                    String nombre = txtNombre.getText().toString();
                    Integer posicion = Integer.parseInt(txtPos.getText().toString());
                    if ((posicion > 0) && (posicion < 256)){
                        //Todo ok
                        //No se aceptan algunos caracteres
                        nombre = nombre.replaceAll("[!,]",".");
                        Log.d("log",nombre);
                        //envio el comando
                        comandos.nuevaPosicion(posicion,nombre,motorSeleccionado);
                        mostrarMensaje("Command sent");
                    } else{
                        mostrarMensaje("Position index not valid");
                    }
                }
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //cancelar
            }
        });

        // muestro el dialogo
        AlertDialog dialog = builder.create();
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#303030")));
        dialog.getWindow().setTitleColor(Color.parseColor("#FFFFFF"));

        dialog.show();

    }

    //Obtener estado posicionador
    private void obtenerStatusPosicionador(final View root){
        class comandoObtenerEstado extends AsyncTask<String, Integer, String> {
            @Override
            protected String doInBackground(String... params) {
                String datos = "";
                DatagramSocket socket = null;
                try {
                    //Preparo y envio el comando gs
                    String comando = "gs"; //comando para que nos devuelva la IP
                    byte[] comandoBytes = comando.getBytes();
                    InetAddress ipBroadcast = InetAddress.getByName(comandos.getIpPosicionador()); //IP de broadcast
                    socket = new DatagramSocket();
                    DatagramPacket paquete = new DatagramPacket(comandoBytes, comandoBytes.length, ipBroadcast, 4567); //puerto 4567
                    socket.send(paquete);

                    //Esperar la respuesta
                    while (true) {
                        try {
                            byte[] respuesta = new byte[100];
                            DatagramPacket paqueteRespuesta = new DatagramPacket(respuesta, respuesta.length);
                            socket.setSoTimeout(5000); //Esperamos la respuesta por 5 segundos
                            socket.receive(paqueteRespuesta);
                            datos = new String(respuesta, 0, paqueteRespuesta.getLength());

                            //si tenemos los datos
                            if (!datos.equals("")){
                               break;
                            }
                        } catch (Exception e) { //si se genera una excepcion rompo el bucle
                            //e.printStackTrace();
                            break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }finally {
                    if (socket != null){
                        Log.d("log","cierra socket");
                        socket.close();
                    }
                }
                return datos;
            }

            @Override
            protected void onPostExecute(String datos) {
                try {
                    Log.d("log", "estado:" + " " + datos);
                    //Cargo los datos
                    String[] respuesta = datos.split(",");
                    TextView lblPulsosMotor1 = root.findViewById(R.id.lblM1Pulses);
                    TextView lblPositionM1 = root.findViewById(R.id.lblM1Position);
                    TextView lblPulsosMotor2 = root.findViewById(R.id.lblM2Pulses);
                    TextView lblPositionM2 = root.findViewById(R.id.lblM2Position);

                    lblPulsosMotor1.setText(respuesta[0].toString());
                    lblPositionM1.setText(respuesta[1].toString());
                    lblPulsosMotor2.setText(respuesta[2].toString());
                    lblPositionM2.setText(respuesta[3].toString());

                    //Muestro el motor seleccionado
                    motorSeleccionado = Integer.parseInt(respuesta[4]);

                    final ImageButton btnMotor1 = root.findViewById(R.id.btnMotor1);
                    final ImageButton btnMotor2 = root.findViewById(R.id.btnMotor2);

                    if (motorSeleccionado == 1) {
                        btnMotor1.setColorFilter(Color.parseColor("#FF0266"));
                    } else {
                        btnMotor2.setColorFilter(Color.parseColor("#FF0266"));
                    }
                }catch (Exception e){
                    Log.d("log","error al cargar estado");
                }
            }

            @Override
            protected void onPreExecute() {
                mostrarMensaje("Getting status...");
            }

            @Override
            protected void onProgressUpdate(Integer... num) {
            }
        }
        new comandoObtenerEstado().execute();
    }


    //CONTROLAR NUMEROS DECIMALES INGRESADOS
    //https://www.tutorialspoint.com/how-to-limit-decimal-places-in-android-edittext
    class DecimalDigitsInputFilter implements InputFilter {
        private Pattern mPattern;
        DecimalDigitsInputFilter(int digitsBeforeZero, int digitsAfterZero) {
            mPattern = Pattern.compile("[0-9]{0," + (digitsBeforeZero - 1) + "}+((\\.[0-9]{0," + (digitsAfterZero - 1) + "})?)||(\\.)?");
        }
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            Matcher matcher = mPattern.matcher(dest);
            if (!matcher.matches())
                return "";
            return null;
        }
    }

    //Mostrar un mensaje
    private void mostrarMensaje(String msg){
        Snackbar snackBar = Snackbar.make(getActivity().findViewById(android.R.id.content),
                msg, Snackbar.LENGTH_LONG);
        snackBar.show();
    }

}
