package com.example.sdpcontroller;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<clsPosicionadores> posicionadoresIp;
    ConstraintLayout layoutBuscando;
    broadCast busquedaPosicionadores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Array que almacena los posicionadores encontrados en la red
        posicionadoresIp = new ArrayList<clsPosicionadores>();

        //Layout que muestra la animacion de busqueda
        layoutBuscando = findViewById(R.id.layoutBuscandoPosicionador);
        layoutBuscando.setVisibility(View.INVISIBLE);

        //Buscar posicionadores en la RED
        busquedaPosicionadores = new broadCast();
        busquedaPosicionadores.execute();

        //listener para la lista de posicionadores
        ListView listView = findViewById(R.id.lstPosicionadores);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Paramos la busqueda
                busquedaPosicionadores.cancel(true);

                //obtengo el posicionador
                clsPosicionadores elPosicionador = (clsPosicionadores) posicionadoresIp.get(position);

                //Seteamos la ip del posicionador seleccionado
                final clsVariablesGlobales variablesGlobales = (clsVariablesGlobales) getApplicationContext();
                variablesGlobales.setIpPosicionador(elPosicionador.getIp());

                //Mostramos el form de control
                Intent intent = new Intent(view.getContext(), frmControlPosicionador.class);
                startActivity(intent);
            }
        });


    }

        //ENVIAR MENSAJE BROADCAST PARA ENCONTRAR LOS POSICIONADORES EN LA RED
            class broadCast extends AsyncTask<String, Integer, Integer> {
                @Override
                protected Integer doInBackground(String... params) {
                    DatagramSocket socket = null;
                    try {
                        /*Preparo y envio el comando '!+' a todos los dipositivos en la RED.
                        Nuestro posicionador esta programado para responder a ese comando con su nombre e IP separado por ,*/
                        String comando = "!+"; //comando para que nos devuelva la IP
                        byte[] comandoBytes = comando.getBytes();
                        InetAddress ipBroadcast = InetAddress.getByName("255.255.255.255"); //IP de broadcast
                        socket = new DatagramSocket();
                        DatagramPacket paquete = new DatagramPacket(comandoBytes, comandoBytes.length, ipBroadcast, 4567); //puerto 4567
                        socket.send(paquete);

                        //Esperar la respuesta
                        while (true) {
                            try {
                                //Verificamos si no fue cancelada
                                if (isCancelled()){
                                    break; //rompemos el bucle
                                }

                                byte[] respuesta = new byte[40];
                                DatagramPacket paqueteRespuesta = new DatagramPacket(respuesta, respuesta.length);
                                socket.setSoTimeout(5000); //Buscamos posicionadores por 5 segundos
                                socket.receive(paqueteRespuesta);
                                String posicionadorDatos = new String(respuesta, 0, paqueteRespuesta.getLength());

                                //si encontramos un posicionador, la agregamos al array
                                if (!posicionadorDatos.equals("")){
                                   clsPosicionadores unPosicionador = new clsPosicionadores();
                                   String[] datos = posicionadorDatos.split(",");
                                   unPosicionador.setNombre(datos[0]);
                                   unPosicionador.setIp(datos[1]);
                                   posicionadoresIp.add(unPosicionador);

                                    //Actualizamos la lista en la UI
                                    publishProgress(posicionadoresIp.size());
                                }
                            } catch (Exception e) { //si se genera una excepcion rompo el bucle
                                //e.printStackTrace();
                                break;
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }finally {
                       if (socket != null){
                           Log.d("log","cierra socket");
                           socket.close();
                       }
                    }
                    return posicionadoresIp.size();
                }

                @Override
                protected void onPostExecute(Integer cantidad) {
                    //Muestro los posicionadores encontrados
                    Log.d("log", "Posicionadores encontrados:" + String.valueOf(posicionadoresIp.size()));
                    for (int i = 0; i < posicionadoresIp.size(); i++) {
                        Log.d("Posicionador", posicionadoresIp.get(i).getIp());
                    }

                    //Oculto el layout de busqueda
                    layoutBuscando.setVisibility(View.INVISIBLE);
                }

                @Override
                protected void onPreExecute() {
                    //Buscando...
                    layoutBuscando.setVisibility(View.VISIBLE);
                }

                @Override
                protected void onProgressUpdate(Integer... num) {
                    //Actualizamos listado
                    listarPosicionadores();
                }
            }


        //Listar posicionadores
    private void listarPosicionadores(){
        ListView listView = findViewById(R.id.lstPosicionadores);
        listView.setAdapter(new arrayAdapterPosicionadores(getApplicationContext(), posicionadoresIp));}
}

